import { CalculationMode, CalculationResult, SupplyType } from '../types';

export function roundToTwo(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

export function formatINR(amount: number, showDecimals: boolean = true): string {
  if (isNaN(amount) || !isFinite(amount)) return '₹0.00';
  
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(roundToTwo(amount));

  return `₹${formatted}`;
}

export function formatNumberOnly(amount: number): string {
  if (isNaN(amount) || !isFinite(amount)) return '0.00';
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(roundToTwo(amount));
}

export function calculateGst(
  amount: number,
  rate: number,
  mode: CalculationMode,
  supplyType: SupplyType
): CalculationResult {
  const safeAmount = Math.max(0, isNaN(amount) ? 0 : amount);
  const safeRate = Math.max(0, isNaN(rate) ? 0 : rate);
  const halfRate = roundToTwo(safeRate / 2);

  let netAmount = 0;
  let totalTaxAmount = 0;
  let grossAmount = 0;
  let cgstAmount = 0;
  let sgstAmount = 0;
  let igstAmount = 0;

  if (mode === 'exclusive') {
    // Amount entered is Net Base Price
    netAmount = roundToTwo(safeAmount);
    totalTaxAmount = roundToTwo((safeAmount * safeRate) / 100);
    grossAmount = roundToTwo(netAmount + totalTaxAmount);

    if (supplyType === 'intra_state') {
      cgstAmount = roundToTwo((safeAmount * halfRate) / 100);
      // To prevent rounding discrepancies (e.g. 0.01 mismatch), derive SGST
      sgstAmount = roundToTwo(totalTaxAmount - cgstAmount);
      igstAmount = 0;
    } else {
      igstAmount = totalTaxAmount;
      cgstAmount = 0;
      sgstAmount = 0;
    }
  } else {
    // Amount entered is Gross Amount (Inclusive of GST)
    grossAmount = roundToTwo(safeAmount);
    // Base = Gross / (1 + Rate / 100)
    netAmount = roundToTwo((safeAmount * 100) / (100 + safeRate));
    totalTaxAmount = roundToTwo(grossAmount - netAmount);

    if (supplyType === 'intra_state') {
      cgstAmount = roundToTwo(totalTaxAmount / 2);
      sgstAmount = roundToTwo(totalTaxAmount - cgstAmount);
      igstAmount = 0;
    } else {
      igstAmount = totalTaxAmount;
      cgstAmount = 0;
      sgstAmount = 0;
    }
  }

  const baseFormula =
    mode === 'exclusive'
      ? `Net Amount = ${formatINR(netAmount)}`
      : `Net Base = ${formatINR(grossAmount)} ÷ (1 + ${safeRate}%) = ${formatINR(netAmount)}`;

  const cgstFormula =
    supplyType === 'intra_state'
      ? `CGST (${halfRate}%) = ${formatINR(netAmount)} × ${halfRate}% = ${formatINR(cgstAmount)}`
      : 'CGST = N/A (Inter-state supply)';

  const sgstFormula =
    supplyType === 'intra_state'
      ? `SGST (${halfRate}%) = ${formatINR(netAmount)} × ${halfRate}% = ${formatINR(sgstAmount)}`
      : 'SGST = N/A (Inter-state supply)';

  const totalFormula =
    mode === 'exclusive'
      ? `Total = Net (${formatINR(netAmount)}) + GST (${formatINR(totalTaxAmount)}) = ${formatINR(grossAmount)}`
      : `GST Extracted = Gross (${formatINR(grossAmount)}) - Net (${formatINR(netAmount)}) = ${formatINR(totalTaxAmount)}`;

  return {
    inputAmount: safeAmount,
    mode,
    supplyType,
    gstRate: safeRate,
    cgstRate: supplyType === 'intra_state' ? halfRate : 0,
    sgstRate: supplyType === 'intra_state' ? halfRate : 0,
    netAmount,
    cgstAmount,
    sgstAmount,
    igstAmount,
    totalTaxAmount,
    grossAmount,
    formulaDescription: {
      baseFormula,
      cgstFormula,
      sgstFormula,
      totalFormula,
    },
  };
}

export const COMMON_GST_RATES = [
  { rate: 0, label: '0%', cgst: '0%', sgst: '0%', description: 'Exempt items (milk, salt, grains)' },
  { rate: 3, label: '3%', cgst: '1.5%', sgst: '1.5%', description: 'Gold, silver & precious jewellery' },
  { rate: 5, label: '5%', cgst: '2.5%', sgst: '2.5%', description: 'Household essentials, edible oils' },
  { rate: 12, label: '12%', cgst: '6%', sgst: '6%', description: 'Computers, processed foods, medicines' },
  { rate: 18, label: '18%', cgst: '9%', sgst: '9%', description: 'Standard rate (IT, services, electronics)' },
  { rate: 28, label: '28%', cgst: '14%', sgst: '14%', description: 'Luxury items, automobiles, ACs' },
];
