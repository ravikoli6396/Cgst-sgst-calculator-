import React, { useState, useId } from 'react';
import { 
  CalculationMode, 
  CalculationResult, 
  SupplyType,
  BillItem 
} from '../types';
import { 
  calculateGst, 
  formatINR, 
  COMMON_GST_RATES 
} from '../utils/gstCalculations';
import { 
  Copy, 
  Check, 
  PlusCircle, 
  RotateCcw, 
  Divide, 
  Percent, 
  ArrowRightLeft, 
  Landmark, 
  Building2, 
  Calculator,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface GstCalculatorProps {
  onAddItemToBill: (item: BillItem) => void;
  selectedRateFromGuide?: number | null;
}

export const GstCalculator: React.FC<GstCalculatorProps> = ({ 
  onAddItemToBill, 
  selectedRateFromGuide 
}) => {
  const [amountStr, setAmountStr] = useState<string>('10000');
  const [rate, setRate] = useState<number>(18);
  const [isCustomRate, setIsCustomRate] = useState<boolean>(false);
  const [customRateStr, setCustomRateStr] = useState<string>('18');
  const [mode, setMode] = useState<CalculationMode>('exclusive');
  const [supplyType, setSupplyType] = useState<SupplyType>('intra_state');
  const [itemDescription, setItemDescription] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [showFormulas, setShowFormulas] = useState<boolean>(false);

  const amountInputId = useId();
  const customRateInputId = useId();
  const descInputId = useId();

  // Sync rate if user clicked "Use" in the guide
  React.useEffect(() => {
    if (selectedRateFromGuide !== undefined && selectedRateFromGuide !== null) {
      setRate(selectedRateFromGuide);
      setIsCustomRate(false);
    }
  }, [selectedRateFromGuide]);

  const numericAmount = parseFloat(amountStr) || 0;
  const activeRate = isCustomRate ? (parseFloat(customRateStr) || 0) : rate;

  const result: CalculationResult = calculateGst(
    numericAmount,
    activeRate,
    mode,
    supplyType
  );

  const handleAmountChange = (val: string) => {
    // Only allow numbers and up to 2 decimal places
    const clean = val.replace(/[^0-9.]/g, '');
    const parts = clean.split('.');
    if (parts.length > 2) return;
    if (parts[1] && parts[1].length > 2) return;
    setAmountStr(clean);
  };

  const addPreset = (addVal: number) => {
    const current = parseFloat(amountStr) || 0;
    const updated = Math.round((current + addVal) * 100) / 100;
    setAmountStr(updated.toString());
  };

  const handleClear = () => {
    setAmountStr('');
  };

  const handleCopyBreakdown = () => {
    const isIntra = supplyType === 'intra_state';
    const textLines = [
      '===============================',
      '     GST CALCULATION SUMMARY    ',
      '===============================',
      `Supply Type: ${isIntra ? 'Intra-State (CGST + SGST)' : 'Inter-State (IGST)'}`,
      `Calculation: ${mode === 'exclusive' ? 'GST Exclusive (+Tax)' : 'GST Inclusive (-Tax)'}`,
      `Input Amount: ${formatINR(result.inputAmount)}`,
      `Tax Rate: ${result.gstRate}%`,
      '-------------------------------',
      `Net Base Price: ${formatINR(result.netAmount)}`,
      ...(isIntra
        ? [
            `CGST (${result.cgstRate}%): ${formatINR(result.cgstAmount)}`,
            `SGST (${result.sgstRate}%): ${formatINR(result.sgstAmount)}`,
          ]
        : [`IGST (${result.gstRate}%): ${formatINR(result.igstAmount)}`]),
      `Total GST: ${formatINR(result.totalTaxAmount)}`,
      '-------------------------------',
      `TOTAL INVOICE AMOUNT: ${formatINR(result.grossAmount)}`,
      '===============================',
    ];

    navigator.clipboard.writeText(textLines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddCurrentToBill = () => {
    if (numericAmount <= 0) return;
    const desc = itemDescription.trim() || `Item @ ${activeRate}% GST`;
    const newItem: BillItem = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      description: desc,
      originalAmount: numericAmount,
      mode,
      supplyType,
      gstRate: activeRate,
      netAmount: result.netAmount,
      cgstAmount: result.cgstAmount,
      sgstAmount: result.sgstAmount,
      igstAmount: result.igstAmount,
      totalTax: result.totalTaxAmount,
      grossAmount: result.grossAmount,
    };
    onAddItemToBill(newItem);
    setItemDescription('');
  };

  // Percentages for the visual progress bar
  const netRatio = result.grossAmount > 0 ? (result.netAmount / result.grossAmount) * 100 : 100;
  const cgstRatio = result.grossAmount > 0 ? (result.cgstAmount / result.grossAmount) * 100 : 0;
  const sgstRatio = result.grossAmount > 0 ? (result.sgstAmount / result.grossAmount) * 100 : 0;
  const igstRatio = result.grossAmount > 0 ? (result.igstAmount / result.grossAmount) * 100 : 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Top Mode Selection */}
      <div className="border-b border-slate-200 bg-slate-50/60 p-2 sm:p-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5">
          {/* Exclusive vs Inclusive Tabs */}
          <div className="flex w-full sm:w-auto p-1 bg-slate-200/70 rounded-xl">
            <button
              id="mode-exclusive-btn"
              type="button"
              onClick={() => setMode('exclusive')}
              className={`flex-1 sm:flex-none px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                mode === 'exclusive'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              GST Exclusive (+Add GST)
            </button>
            <button
              id="mode-inclusive-btn"
              type="button"
              onClick={() => setMode('inclusive')}
              className={`flex-1 sm:flex-none px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                mode === 'inclusive'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              GST Inclusive (-Extract GST)
            </button>
          </div>

          {/* Intra-State (CGST+SGST) vs Inter-State (IGST) */}
          <div className="flex w-full sm:w-auto items-center justify-end gap-1.5 text-xs">
            <span className="text-slate-500 font-medium hidden md:inline">Supply Type:</span>
            <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-white">
              <button
                id="supply-intra-btn"
                type="button"
                onClick={() => setSupplyType('intra_state')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                  supplyType === 'intra_state'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Intra-State (CGST + SGST)
              </button>
              <button
                id="supply-inter-btn"
                type="button"
                onClick={() => setSupplyType('inter_state')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  supplyType === 'inter_state'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Inter-State (IGST)
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-5 sm:p-7">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7">
          {/* Left Column: Inputs */}
          <div className="lg:col-span-6 space-y-6">
            {/* Amount Input */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label 
                  htmlFor={amountInputId} 
                  className="text-xs font-bold uppercase tracking-wider text-slate-700"
                >
                  {mode === 'exclusive' ? 'Net Base Amount (₹)' : 'Gross MRP / Total Amount (₹)'}
                </label>
                {amountStr && (
                  <button
                    id="clear-amount-btn"
                    type="button"
                    onClick={handleClear}
                    className="text-xs font-medium text-slate-400 hover:text-rose-600 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Clear
                  </button>
                )}
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 text-2xl font-semibold">
                  ₹
                </div>
                <input
                  id={amountInputId}
                  type="text"
                  inputMode="decimal"
                  value={amountStr}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-300 rounded-xl text-2xl font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all tracking-tight"
                />
              </div>

              {/* Quick Add Buttons */}
              <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                <span className="text-[11px] text-slate-400 mr-1 font-medium">Quick Add:</span>
                {[500, 1000, 5000, 10000, 50000, 100000].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => addPreset(val)}
                    className="text-[11px] font-medium py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 transition-colors cursor-pointer border border-slate-200/60"
                  >
                    +{val >= 100000 ? `${val / 100000}L` : val >= 1000 ? `${val / 1000}k` : val}
                  </button>
                ))}
              </div>
            </div>

            {/* GST Rate Slabs */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Select GST Rate (%)
                </label>
                {supplyType === 'intra_state' && (
                  <span className="text-xs font-medium text-slate-500">
                    Split: <strong className="text-emerald-700">{(activeRate / 2).toFixed(1)}% CGST</strong> + <strong className="text-blue-700">{(activeRate / 2).toFixed(1)}% SGST</strong>
                  </span>
                )}
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {COMMON_GST_RATES.map((item) => {
                  const isSelected = !isCustomRate && rate === item.rate;
                  return (
                    <button
                      key={item.rate}
                      id={`rate-btn-${item.rate}`}
                      type="button"
                      onClick={() => {
                        setIsCustomRate(false);
                        setRate(item.rate);
                      }}
                      className={`py-3 px-2 rounded-xl text-center border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm ring-2 ring-indigo-200'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="text-base font-bold">{item.label}</div>
                      {supplyType === 'intra_state' && item.rate > 0 ? (
                        <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-indigo-100' : 'text-slate-500'}`}>
                          {item.cgst} + {item.sgst}
                        </div>
                      ) : (
                        <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-indigo-100' : 'text-slate-400'}`}>
                          {item.rate === 0 ? 'Exempt' : 'Full IGST'}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Custom Rate Toggle */}
              <div className="mt-3 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsCustomRate(!isCustomRate)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
                    isCustomRate
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Percent className="w-3.5 h-3.5" />
                  {isCustomRate ? 'Using Custom Rate' : 'Enter Custom Rate'}
                </button>

                {isCustomRate && (
                  <div className="flex items-center gap-1.5">
                    <input
                      id={customRateInputId}
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={customRateStr}
                      onChange={(e) => setCustomRateStr(e.target.value)}
                      placeholder="e.g. 7.5"
                      className="w-24 px-2.5 py-1 text-xs border border-indigo-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold text-slate-900 bg-white"
                    />
                    <span className="text-xs font-bold text-slate-600">%</span>
                  </div>
                )}
              </div>
            </div>

            {/* Optional Item Note / Add to invoice */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2.5">
              <label 
                htmlFor={descInputId} 
                className="text-xs font-medium text-slate-600 flex items-center justify-between"
              >
                <span>Add Item to Consolidated Bill (Optional):</span>
              </label>
              <div className="flex gap-2">
                <input
                  id={descInputId}
                  type="text"
                  value={itemDescription}
                  onChange={(e) => setItemDescription(e.target.value)}
                  placeholder="e.g., Laptop, Consulting, Office Supplies"
                  className="flex-1 px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  id="add-to-bill-btn"
                  type="button"
                  onClick={handleAddCurrentToBill}
                  disabled={numericAmount <= 0}
                  className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  <PlusCircle className="w-4 h-4" />
                  Add to Bill
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Calculations & Results */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-5">
            {/* Primary CGST and SGST Display Card */}
            <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-indigo-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Tax Breakdown ({result.gstRate}%)
                  </span>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {mode === 'exclusive' ? 'Tax Added' : 'Tax Included'}
                </span>
              </div>

              {supplyType === 'intra_state' ? (
                /* Intra-State: Side-by-side CGST & SGST cards */
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  {/* CGST */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-emerald-500/30 relative overflow-hidden">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                        <Landmark className="w-4 h-4" />
                        <span>CGST</span>
                      </div>
                      <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {result.cgstRate}%
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mb-1">Central Government Share</div>
                    <div className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                      {formatINR(result.cgstAmount)}
                    </div>
                  </div>

                  {/* SGST */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-blue-500/30 relative overflow-hidden">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-blue-400">
                        <Building2 className="w-4 h-4" />
                        <span>SGST / UTGST</span>
                      </div>
                      <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                        {result.sgstRate}%
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mb-1">State Government Share</div>
                    <div className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                      {formatINR(result.sgstAmount)}
                    </div>
                  </div>
                </div>
              ) : (
                /* Inter-State: IGST single card */
                <div className="p-4 rounded-xl bg-slate-800/80 border border-purple-500/30 mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-purple-400">IGST (Integrated GST)</span>
                    <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
                      {result.gstRate}%
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mb-1">Inter-State Transaction</div>
                  <div className="text-2xl font-extrabold text-white tracking-tight">
                    {formatINR(result.igstAmount)}
                  </div>
                </div>
              )}

              {/* Summary Numbers */}
              <div className="space-y-2.5 pt-2 border-t border-slate-800 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Net Base Amount:</span>
                  <span className="font-semibold text-white">{formatINR(result.netAmount)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>Total Tax (GST):</span>
                  <span className="font-semibold text-amber-400">{formatINR(result.totalTaxAmount)}</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-sm font-bold text-white">
                  <span>Gross Invoice Total:</span>
                  <span className="text-xl font-extrabold text-indigo-400">{formatINR(result.grossAmount)}</span>
                </div>
              </div>

              {/* Visual Proportion Bar */}
              <div className="mt-4 pt-3 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                  <span>Visual Composition</span>
                  <span>100% Total</span>
                </div>
                <div className="h-2.5 w-full rounded-full bg-slate-800 overflow-hidden flex">
                  <div 
                    style={{ width: `${netRatio}%` }} 
                    className="bg-slate-400 transition-all duration-300"
                    title={`Base: ${netRatio.toFixed(1)}%`}
                  />
                  {supplyType === 'intra_state' ? (
                    <>
                      <div 
                        style={{ width: `${cgstRatio}%` }} 
                        className="bg-emerald-500 transition-all duration-300"
                        title={`CGST: ${cgstRatio.toFixed(1)}%`}
                      />
                      <div 
                        style={{ width: `${sgstRatio}%` }} 
                        className="bg-blue-500 transition-all duration-300"
                        title={`SGST: ${sgstRatio.toFixed(1)}%`}
                      />
                    </>
                  ) : (
                    <div 
                      style={{ width: `${igstRatio}%` }} 
                      className="bg-purple-500 transition-all duration-300"
                      title={`IGST: ${igstRatio.toFixed(1)}%`}
                    />
                  )}
                </div>
                <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-2">
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                    <span>Base ({netRatio.toFixed(1)}%)</span>
                  </div>
                  {supplyType === 'intra_state' ? (
                    <>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        <span className="text-emerald-400">CGST ({cgstRatio.toFixed(1)}%)</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                        <span className="text-blue-400">SGST ({sgstRatio.toFixed(1)}%)</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                      <span className="text-purple-400">IGST ({igstRatio.toFixed(1)}%)</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-2">
              <button
                id="copy-breakdown-btn"
                type="button"
                onClick={handleCopyBreakdown}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-700 font-bold">Summary Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>Copy Breakdown</span>
                  </>
                )}
              </button>

              <button
                id="toggle-formula-btn"
                type="button"
                onClick={() => setShowFormulas(!showFormulas)}
                className="py-2.5 px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-medium text-slate-600 flex items-center gap-1 cursor-pointer transition-colors"
                title="Toggle Step-by-Step Formula"
              >
                <Divide className="w-3.5 h-3.5" />
                <span>Formula</span>
                {showFormulas ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Step-by-step formula math breakdown */}
            {showFormulas && (
              <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 text-xs space-y-2">
                <div className="font-bold text-indigo-950 flex items-center gap-1.5">
                  <Divide className="w-4 h-4 text-indigo-600" />
                  Calculation Formulas & Step-by-step Arithmetic
                </div>
                <div className="space-y-1.5 text-slate-700 font-mono text-[11px]">
                  <div className="p-1.5 rounded bg-white border border-indigo-100">
                    <span className="text-indigo-800 font-bold">1. Base Price:</span> {result.formulaDescription.baseFormula}
                  </div>
                  {supplyType === 'intra_state' ? (
                    <>
                      <div className="p-1.5 rounded bg-white border border-indigo-100">
                        <span className="text-emerald-800 font-bold">2. CGST:</span> {result.formulaDescription.cgstFormula}
                      </div>
                      <div className="p-1.5 rounded bg-white border border-indigo-100">
                        <span className="text-blue-800 font-bold">3. SGST:</span> {result.formulaDescription.sgstFormula}
                      </div>
                    </>
                  ) : (
                    <div className="p-1.5 rounded bg-white border border-indigo-100">
                      <span className="text-purple-800 font-bold">2. IGST:</span> {result.formulaDescription.totalFormula}
                    </div>
                  )}
                  <div className="p-1.5 rounded bg-white border border-indigo-100">
                    <span className="text-slate-900 font-bold">Final Total:</span> {result.formulaDescription.totalFormula}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
