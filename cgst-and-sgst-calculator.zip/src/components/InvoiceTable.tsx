import React from 'react';
import { BillItem } from '../types';
import { formatINR } from '../utils/gstCalculations';
import { Trash2, Plus, Download, Printer, FileText } from 'lucide-react';

interface InvoiceTableProps {
  items: BillItem[];
  onRemoveItem: (id: string) => void;
  onClearAll: () => void;
}

export const InvoiceTable: React.FC<InvoiceTableProps> = ({ items, onRemoveItem, onClearAll }) => {
  if (items.length === 0) {
    return null;
  }

  const totalBase = items.reduce((acc, item) => acc + item.netAmount, 0);
  const totalCgst = items.reduce((acc, item) => acc + item.cgstAmount, 0);
  const totalSgst = items.reduce((acc, item) => acc + item.sgstAmount, 0);
  const totalIgst = items.reduce((acc, item) => acc + item.igstAmount, 0);
  const totalTax = items.reduce((acc, item) => acc + item.totalTax, 0);
  const grandTotal = items.reduce((acc, item) => acc + item.grossAmount, 0);

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = ['Description', 'Input Amount', 'Type', 'GST Rate', 'Base Amount', 'CGST', 'SGST', 'IGST', 'Total Tax', 'Gross Amount'];
    const rows = items.map(item => [
      `"${item.description.replace(/"/g, '""')}"`,
      item.originalAmount.toFixed(2),
      item.mode === 'exclusive' ? 'Exclusive (+GST)' : 'Inclusive (-GST)',
      `${item.gstRate}%`,
      item.netAmount.toFixed(2),
      item.cgstAmount.toFixed(2),
      item.sgstAmount.toFixed(2),
      item.igstAmount.toFixed(2),
      item.totalTax.toFixed(2),
      item.grossAmount.toFixed(2)
    ]);

    const summaryRow = [
      '"TOTAL"',
      '',
      '',
      '',
      totalBase.toFixed(2),
      totalCgst.toFixed(2),
      totalSgst.toFixed(2),
      totalIgst.toFixed(2),
      totalTax.toFixed(2),
      grandTotal.toFixed(2)
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(',')), summaryRow.join(',')].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `gst_calculation_bill_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs print:border-none print:p-0">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Tally & Invoice Summary ({items.length} {items.length === 1 ? 'item' : 'items'})
          </h2>
          <p className="text-xs text-slate-500">Accumulated line items with consolidated CGST and SGST splits</p>
        </div>

        <div className="flex items-center gap-2 print:hidden">
          <button
            type="button"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Slip
          </button>
          <button
            type="button"
            onClick={onClearAll}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
            <tr>
              <th className="py-2.5 px-3">Item / Description</th>
              <th className="py-2.5 px-3">Rate</th>
              <th className="py-2.5 px-3 text-right">Net Base</th>
              <th className="py-2.5 px-3 text-right text-emerald-700">CGST</th>
              <th className="py-2.5 px-3 text-right text-blue-700">SGST</th>
              <th className="py-2.5 px-3 text-right">Total Tax</th>
              <th className="py-2.5 px-3 text-right font-bold">Gross Total</th>
              <th className="py-2.5 px-2 text-center print:hidden"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-600">
            {items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50/50">
                <td className="py-2.5 px-3 font-medium text-slate-800">{item.description}</td>
                <td className="py-2.5 px-3">
                  <span className="inline-block px-1.5 py-0.5 rounded bg-slate-100 font-semibold text-slate-700">
                    {item.gstRate}%
                  </span>
                </td>
                <td className="py-2.5 px-3 text-right">{formatINR(item.netAmount)}</td>
                <td className="py-2.5 px-3 text-right text-emerald-700 font-medium">
                  {item.cgstAmount > 0 ? formatINR(item.cgstAmount) : '-'}
                </td>
                <td className="py-2.5 px-3 text-right text-blue-700 font-medium">
                  {item.sgstAmount > 0 ? formatINR(item.sgstAmount) : '-'}
                </td>
                <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                  {formatINR(item.totalTax)}
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                  {formatINR(item.grossAmount)}
                </td>
                <td className="py-2.5 px-2 text-center print:hidden">
                  <button
                    type="button"
                    onClick={() => onRemoveItem(item.id)}
                    className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-slate-50 font-semibold text-slate-900 border-t-2 border-slate-200">
            <tr>
              <td className="py-3 px-3 uppercase text-xs tracking-wider" colSpan={2}>
                Total ({items.length} items)
              </td>
              <td className="py-3 px-3 text-right">{formatINR(totalBase)}</td>
              <td className="py-3 px-3 text-right text-emerald-700 font-bold">{formatINR(totalCgst)}</td>
              <td className="py-3 px-3 text-right text-blue-700 font-bold">{formatINR(totalSgst)}</td>
              <td className="py-3 px-3 text-right text-indigo-700 font-bold">{formatINR(totalTax)}</td>
              <td className="py-3 px-3 text-right text-indigo-900 text-sm font-extrabold">{formatINR(grandTotal)}</td>
              <td className="print:hidden"></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-100">
        <div className="p-2.5 rounded-xl bg-slate-50">
          <span className="text-[11px] text-slate-500 block">Total Net (Excl. Tax)</span>
          <span className="text-sm font-bold text-slate-800">{formatINR(totalBase)}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
          <span className="text-[11px] text-emerald-700 block">Consolidated CGST</span>
          <span className="text-sm font-bold text-emerald-800">{formatINR(totalCgst)}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-100">
          <span className="text-[11px] text-blue-700 block">Consolidated SGST</span>
          <span className="text-sm font-bold text-blue-800">{formatINR(totalSgst)}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-100">
          <span className="text-[11px] text-indigo-700 block">Grand Total (Incl. Tax)</span>
          <span className="text-sm font-bold text-indigo-900">{formatINR(grandTotal)}</span>
        </div>
      </div>
    </div>
  );
};
