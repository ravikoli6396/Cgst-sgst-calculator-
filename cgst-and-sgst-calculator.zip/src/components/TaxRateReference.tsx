import React from 'react';
import { HelpCircle, Info, CheckCircle2, ArrowRight } from 'lucide-react';
import { COMMON_GST_RATES } from '../utils/gstCalculations';

interface TaxRateReferenceProps {
  onSelectRate?: (rate: number) => void;
}

export const TaxRateReference: React.FC<TaxRateReferenceProps> = ({ onSelectRate }) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
      <div className="flex items-center gap-2 mb-4">
        <Info className="w-5 h-5 text-indigo-600" />
        <h2 className="text-base font-bold text-slate-900">Understanding CGST & SGST</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="text-sm font-bold text-slate-800">CGST</span>
          </div>
          <p className="text-xs text-slate-500 font-medium mb-2">Central Goods & Services Tax</p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Levied by the <strong>Central Government</strong> on intra-state supplies of goods and services. Equals exactly 50% of total GST rate.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            <span className="text-sm font-bold text-slate-800">SGST / UTGST</span>
          </div>
          <p className="text-xs text-slate-500 font-medium mb-2">State / Union Territory GST</p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Levied by the <strong>State or UT Government</strong> where consumption takes place. Equals exactly 50% of total GST rate.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-purple-500"></span>
            <span className="text-sm font-bold text-slate-800">IGST</span>
          </div>
          <p className="text-xs text-slate-500 font-medium mb-2">Integrated GST</p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Applies to <strong>inter-state</strong> transactions (between different states or import/export). Levied at the full rate without CGST/SGST split.
          </p>
        </div>
      </div>

      <div>
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
          Standard GST Slabs & CGST/SGST Breakdown
        </h3>
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Total GST</th>
                <th className="py-2.5 px-3 text-emerald-700">CGST (Central)</th>
                <th className="py-2.5 px-3 text-blue-700">SGST (State)</th>
                <th className="py-2.5 px-3">Typical Items</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-600">
              {COMMON_GST_RATES.map((item) => (
                <tr key={item.rate} className="hover:bg-indigo-50/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{item.label}</td>
                  <td className="py-2.5 px-3 font-semibold text-emerald-700">{item.cgst}</td>
                  <td className="py-2.5 px-3 font-semibold text-blue-700">{item.sgst}</td>
                  <td className="py-2.5 px-3 text-slate-500 max-w-[200px] truncate">{item.description}</td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => onSelectRate && onSelectRate(item.rate)}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 transition-colors py-0.5 px-2 rounded hover:bg-indigo-100/60 cursor-pointer"
                    >
                      Use
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
