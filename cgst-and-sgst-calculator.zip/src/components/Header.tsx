import React from 'react';
import { Calculator, Landmark, Building2, ShieldCheck } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              CGST & SGST Calculator
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                GST India
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Calculate Central GST (CGST) and State GST (SGST) for intra-state & inter-state billing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-medium">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200/60">
            <Landmark className="w-3.5 h-3.5 text-emerald-600" />
            <span>CGST (Central 50%)</span>
          </div>
          <span className="text-slate-400 font-bold">+</span>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200/60">
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            <span>SGST (State 50%)</span>
          </div>
        </div>
      </div>
    </header>
  );
};
