/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useId } from 'react';
import { 
  Calculator, 
  Copy, 
  Check, 
  RotateCcw, 
  Building2, 
  Landmark, 
  Percent 
} from 'lucide-react';

const GST_RATES = [5, 12, 18, 28];

export default function App() {
  const [amount, setAmount] = useState<string>('1000');
  const [rate, setRate] = useState<number>(18);
  const [isCustomRate, setIsCustomRate] = useState<boolean>(false);
  const [customRate, setCustomRate] = useState<string>('18');
  const [mode, setMode] = useState<'exclusive' | 'inclusive'>('exclusive');
  const [copied, setCopied] = useState<boolean>(false);

  const amountInputId = useId();
  const customRateInputId = useId();

  const numAmount = parseFloat(amount) || 0;
  const activeRate = isCustomRate ? (parseFloat(customRate) || 0) : rate;
  const halfRate = activeRate / 2;

  // Rounding helper
  const round = (val: number) => Math.round((val + Number.EPSILON) * 100) / 100;

  // Calculations
  let baseAmount = 0;
  let totalTax = 0;
  let grossAmount = 0;
  let cgstAmount = 0;
  let sgstAmount = 0;

  if (mode === 'exclusive') {
    // Amount is Base Price (Add GST)
    baseAmount = round(numAmount);
    totalTax = round((numAmount * activeRate) / 100);
    grossAmount = round(baseAmount + totalTax);
    cgstAmount = round((numAmount * halfRate) / 100);
    sgstAmount = round(totalTax - cgstAmount); // Prevent 1 paisa rounding mismatch
  } else {
    // Amount is Gross MRP (Remove GST)
    grossAmount = round(numAmount);
    baseAmount = round((numAmount * 100) / (100 + activeRate));
    totalTax = round(grossAmount - baseAmount);
    cgstAmount = round(totalTax / 2);
    sgstAmount = round(totalTax - cgstAmount);
  }

  const formatINR = (val: number) => {
    return '₹' + new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(round(val));
  };

  const handleAmountChange = (val: string) => {
    const cleaned = val.replace(/[^0-9.]/g, '');
    const parts = cleaned.split('.');
    if (parts.length > 2) return;
    if (parts[1] && parts[1].length > 2) return;
    setAmount(cleaned);
  };

  const handleCopy = () => {
    const text = [
      `Amount: ${formatINR(numAmount)} (${mode === 'exclusive' ? 'Exclusive' : 'Inclusive'})`,
      `GST Rate: ${activeRate}%`,
      `Base Price: ${formatINR(baseAmount)}`,
      `CGST (${halfRate}%): ${formatINR(cgstAmount)}`,
      `SGST (${halfRate}%): ${formatINR(sgstAmount)}`,
      `Total Tax: ${formatINR(totalTax)}`,
      `Total Amount: ${formatINR(grossAmount)}`,
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleReset = () => {
    setAmount('');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-xl mx-auto my-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-600 text-white shadow-md mb-3">
            <Calculator className="w-6 h-6" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            CGST & SGST Calculator
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Simple & fast GST calculation with 50-50 Central & State split
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-lg shadow-slate-200/50 p-5 sm:p-7 space-y-6">
          
          {/* Mode Switch (Add GST vs Remove GST) */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-2xl">
            <button
              id="mode-exclusive"
              type="button"
              onClick={() => setMode('exclusive')}
              className={`py-2.5 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer ${
                mode === 'exclusive'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + Add GST (Exclusive)
            </button>
            <button
              id="mode-inclusive"
              type="button"
              onClick={() => setMode('inclusive')}
              className={`py-2.5 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer ${
                mode === 'inclusive'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              - Remove GST (Inclusive)
            </button>
          </div>

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label 
                htmlFor={amountInputId} 
                className="text-xs font-bold uppercase tracking-wider text-slate-600"
              >
                {mode === 'exclusive' ? 'Base Amount (₹)' : 'Total MRP / Bill Amount (₹)'}
              </label>
              {amount && (
                <button
                  id="reset-btn"
                  type="button"
                  onClick={handleReset}
                  className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  Clear
                </button>
              )}
            </div>

            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 text-2xl font-bold">
                ₹
              </span>
              <input
                id={amountInputId}
                type="text"
                inputMode="decimal"
                value={amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                placeholder="0"
                autoFocus
                className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-300 rounded-2xl text-2xl sm:text-3xl font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all tracking-tight"
              />
            </div>

            {/* Quick Amount Buttons */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
              {[500, 1000, 5000, 10000, 50000].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val.toString())}
                  className="text-xs font-medium py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200 transition-colors cursor-pointer"
                >
                  ₹{val.toLocaleString('en-IN')}
                </button>
              ))}
            </div>
          </div>

          {/* GST Rate Buttons */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                GST Rate (%)
              </span>
              <span className="text-xs font-medium text-slate-500">
                Split: <strong className="text-emerald-700">{halfRate}% CGST</strong> + <strong className="text-blue-700">{halfRate}% SGST</strong>
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {GST_RATES.map((r) => {
                const isSelected = !isCustomRate && rate === r;
                return (
                  <button
                    key={r}
                    id={`rate-${r}`}
                    type="button"
                    onClick={() => {
                      setIsCustomRate(false);
                      setRate(r);
                    }}
                    className={`py-3 px-2 rounded-2xl text-center border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="text-lg font-bold">{r}%</div>
                    <div className={`text-[10px] ${isSelected ? 'text-indigo-100' : 'text-slate-400'}`}>
                      {r / 2}% + {r / 2}%
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom Rate Input */}
            <div className="mt-2.5 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsCustomRate(!isCustomRate)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Percent className="w-3.5 h-3.5" />
                {isCustomRate ? 'Selected standard rate' : 'Other / Custom %'}
              </button>

              {isCustomRate && (
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-500 font-medium">Rate:</span>
                  <input
                    id={customRateInputId}
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={customRate}
                    onChange={(e) => setCustomRate(e.target.value)}
                    placeholder="Rate"
                    className="w-20 px-2.5 py-1 text-sm font-bold border border-indigo-300 rounded-lg text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 text-center"
                  />
                  <span className="text-xs font-bold text-slate-600">%</span>
                </div>
              )}
            </div>
          </div>

          {/* Results: CGST & SGST Split */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            
            {/* CGST & SGST Cards */}
            <div className="grid grid-cols-2 gap-3">
              {/* CGST */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-800">
                    <Landmark className="w-3.5 h-3.5 text-emerald-600" />
                    <span>CGST</span>
                  </div>
                  <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                    {halfRate}%
                  </span>
                </div>
                <div className="text-[11px] text-emerald-600/90">Central Share</div>
                <div className="text-xl sm:text-2xl font-extrabold text-emerald-950 mt-1">
                  {formatINR(cgstAmount)}
                </div>
              </div>

              {/* SGST */}
              <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1 text-xs font-bold text-blue-800">
                    <Building2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>SGST</span>
                  </div>
                  <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">
                    {halfRate}%
                  </span>
                </div>
                <div className="text-[11px] text-blue-600/90">State Share</div>
                <div className="text-xl sm:text-2xl font-extrabold text-blue-950 mt-1">
                  {formatINR(sgstAmount)}
                </div>
              </div>
            </div>

            {/* Total GST & Base & Final Bill Summary */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Net Base Amount:</span>
                <span className="font-semibold text-white">{formatINR(baseAmount)}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Total Tax (CGST + SGST):</span>
                <span className="font-bold text-amber-400">{formatINR(totalTax)}</span>
              </div>
              <div className="h-px bg-slate-800 my-1" />
              <div className="flex items-center justify-between text-sm sm:text-base font-bold text-white">
                <span>Total Final Amount:</span>
                <span className="text-xl sm:text-2xl font-extrabold text-indigo-400">
                  {formatINR(grossAmount)}
                </span>
              </div>
            </div>

            {/* Copy Button */}
            <button
              id="copy-btn"
              type="button"
              onClick={handleCopy}
              className="w-full py-3 px-4 rounded-2xl border border-slate-200 hover:bg-slate-50 text-xs sm:text-sm font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 font-bold">Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-500" />
                  <span>Copy Result</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Short calculation explanation */}
        <p className="text-center text-xs text-slate-400 mt-4">
          Base: {formatINR(baseAmount)} + CGST ({halfRate}%): {formatINR(cgstAmount)} + SGST ({halfRate}%): {formatINR(sgstAmount)} = {formatINR(grossAmount)}
        </p>
      </div>
    </div>
  );
}
