export type CalculationMode = 'exclusive' | 'inclusive';

export type SupplyType = 'intra_state' | 'inter_state';

export interface CalculationResult {
  inputAmount: number;
  mode: CalculationMode;
  supplyType: SupplyType;
  gstRate: number;
  cgstRate: number;
  sgstRate: number;
  netAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalTaxAmount: number;
  grossAmount: number;
  formulaDescription: {
    baseFormula: string;
    cgstFormula: string;
    sgstFormula: string;
    totalFormula: string;
  };
}

export interface BillItem {
  id: string;
  description: string;
  originalAmount: number;
  mode: CalculationMode;
  supplyType: SupplyType;
  gstRate: number;
  netAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalTax: number;
  grossAmount: number;
}
